Setup
=====

1. In your HTML text editor, open the files exercise.css and exercise.html.

2. In your web browser, open the file exercise.html (i.e. File>Open File...).


Exercise 1 - Create two columns: one for navigation content and one for remaining content
=========================================================================================

1. In exercise.html, locate the seven lines of content starting with the comment <!-- navigation content -->.

2. Wrap the seven lines in a div element by using div tags <div> and </div>.

3. Add a class attribute to the div element with value
   left-container 

4. Wrap the main body content (12 lines total) and reference content (4 lines total) in a single div element by using div tags <div> and </div>.

5. Add a class attribute to the div element with value
   right-container

6. Save exercise.html.

7. In your browser, reload exercise.html.
   - There should be no visible change.

8. In your HTML text editor, verify that your changes to exercise.html are correct by comparing with the solution file exercise1.html.


Exercise 2 - Format two columns from left-container and right-container div elements using CSS
==============================================================================================

1. In exercise.css, add a rule to format the div element with class left-container (i.e. the first column) using the properties
   float: left;
   width: 18%;

2. Add a rule to format the div element with class right-container (i.e. the second column) using the properties
   float: right;
   width: 80%;

3. Add a rule to clear the float properties for the footer element using the property
   clear: both;

4. Save exercise.css.

5. In your browser, reload exercise.html.
   - The navigation content appears in the first column (counting from the left) and the remaining content appears in the larger second column.

6. In your HTML text editor, verify that your changes to exercise.css are correct by comparing with the solution file exercise2.css.


Exercise 3 - Subdivide the second column into two columns: one for main body content and one for reference content
==================================================================================================================

1. In exercise.html, locate the twelve lines of content starting with the comment <!-- main body content -->.

2. Wrap the twelve lines in a div element using div tags <div> and </div>.

3. Add a class attribute to the div element with value
   inner-left

4. Locate the four lines of content starting with the comment <!-- reference content -->.

5. Wrap the four lines in a div element using div tags <div> and </div>.

6. Add a class attribute to the div element with value
   inner-right

7. Save exercise.html.

8. In your browser, reload exercise.html.
   - There should be no visible change.

9. In your HTML text editor, verify that your changes to exercise.html are correct by comparing with the solution file exercise3.html.


Exercise 4 - Format two columns from inner-left and inner-right div elements using CSS
======================================================================================

1. In exercise.css, add a rule to format the div element with class inner-left (i.e. the new second column) using the properties
   float: left;
   width: 75%;

2. Add a rule to format the div element with class inner-right (i.e. the third column) using the properties
   float: right;
   width: 22%;

3. Save exercise.css.

4. In your browser, reload exercise.html.
   - The body section of the web page is displayed in three columns. The navigation content appears in the first column (counting from the left), the main body content appears in the second column, and the reference content appears in the third column.

5. In your HTML text editor, verify that your changes to exercise.css are correct by comparing with the solution file exercise4.css.
