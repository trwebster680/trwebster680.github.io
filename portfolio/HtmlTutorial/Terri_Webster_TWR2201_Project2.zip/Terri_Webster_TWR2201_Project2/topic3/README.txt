Setup
=====

1. In your HTML text editor, open the files exercise.css and exercise.html.

2. In your web browser, open the file exercise.html (i.e. File>Open File...).


Exercise 1 - Add a header to your HTML file
===========================================

1. In exercise.html, locate the three lines of content starting with the comment <!-- header content -->.

2. Wrap the three lines in a header element by using header tags <header> and </header>.

3. Save exercise.html.

4. In your browser, reload exercise.html.
   - There should be no visible change.

5. In your HTML text editor, verify that your changes to exercise.html are correct by comparing with the solution file exercise1.html.


Exercise 2 - Add a footer to your HTML file
===========================================

1. In exercise.html, locate the three lines of content starting with the comment <!-- footer content -->.

2. Wrap the three lines in a footer element by using footer tags <footer> and </footer>.

3. Save exercise.html.

4. In your browser, reload exercise.html.
   - There should be no visible change.

5. In your HTML text editor, verify that your changes to exercise.html are correct by comparing with the solution file exercise2.html.


Exercise 3 - Format the header section using CSS
================================================

1. In exercise.css, add a rule to set the header background colour to blue using the property
   background-color: #25aff4;

2. Add a rule to set the font size and alignment properties for paragraph elements in the header section using the properties
   font-size: 10pt;
   text-align: right;

3. Save exercise.css.

4. In your browser, reload exercise.html.
   - The header section should be blue and the author information should be right aligned.

5. In your HTML text editor, verify that your changes to exercise.css are correct by comparing with the solution file exercise3.css.


Exercise 4 - Format the footer section using CSS
================================================

1. In exercise.css, add a rule to set the footer background colour to blue using the property
   background-color: #25aff4;

2. Add a rule to set the font size and font style properties for paragraph elements in the footer section using the properties
   font-size: 8pt;
   font-style: italic;

3. Save exercise.css.

4. In your browser, reload exercise.html.
  - The footer section should be blue and the text should be smaller (compared to what it was initially) and italicised.

5. In your HTML text editor, verify that your changes to exercise.css are correct by comparing with the solution file exercise4.css.
