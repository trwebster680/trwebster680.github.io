Setup
=====

1. In your HTML text editor, open the files exercise.css and exercise.html.

2. In your web browser, open the file exercise.html (i.e. File>Open File...).


Exercise 1 - Extend the first column's background colour using CSS
==================================================================

1. In exercise.css, add a rule to format the div element with class left-container (i.e. the first column) using the properties
   padding-bottom: 99999px;
   margin-bottom: -99999px;

2. Add a rule to format the div element with class content (i.e. the div element that contains the first column) using the property
   overflow: hidden;

3. Save exercise.css.

4. In your browser, reload exercise.html.
   - The first column's background colour extends all the way down to the footer, filling the entire column.

5. In your HTML text editor, verify that your changes to exercise.css are correct by comparing with the solution file exercise1.css.


Exercise 2 - Extend the third column's background colour using CSS
==================================================================

1. In exercise.css, add a rule to format the div element with class inner-right (i.e. the third column) using the properties
   padding-bottom: 99999px;
   margin-bottom: -99999px;

2. Save exercise.css.

3. In your browser, reload exercise.html.
   - The third column's background colour extends all the way down to the footer, filling the entire column.

4. In your HTML text editor, verify that your changes to exercise.css are correct by comparing with the solution file exercise2.css.

